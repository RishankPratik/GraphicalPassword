from django.contrib import admin
from .models import LoginInfo

admin.site.register(LoginInfo)